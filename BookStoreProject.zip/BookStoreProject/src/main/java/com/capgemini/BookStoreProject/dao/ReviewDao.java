package com.capgemini.BookStoreProject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.BookStoreProject.beans.Review;
@Repository
public interface ReviewDao extends JpaRepository<Review, Integer>{

}
