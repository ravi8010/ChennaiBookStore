package com.capgemini.BookStoreProject.service;

import java.util.List;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Review;

public interface CustomerService {
	
	public Book findInformation(int bookId);
    public List<Review> booksReview();

}
