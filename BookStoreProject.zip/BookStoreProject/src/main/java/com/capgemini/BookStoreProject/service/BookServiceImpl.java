package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.dao.BookDao;

@Service
public class BookServiceImpl implements BookService {
	
	@Autowired
	private BookDao bookDao;

	@Override
	public List<Book> allBooks() {
		return bookDao.findAll();

	}

	@Override
	public Book createBook(Book book) {

		return bookDao.saveAndFlush(book);
		

	}

	@Override
	public Book delete(int id) {
		if (bookDao.findById(id) != null)
			bookDao.deleteById(id);
		return null;
	}

	@Override
	public Book update(int id, Book book) {
		book = bookDao.findById(id).get();
		bookDao.saveAndFlush(book);
		bookDao.flush();
		return book;

	}

	@Override
	public Book findBook(int id) {

		if (bookDao.findById(id) == null)
			return null;

		return bookDao.findById(id).get();
	}

}
