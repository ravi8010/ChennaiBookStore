package com.capgemini.BookStoreProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.service.BookService;
@RestController
public class BookController {
	
	
	@Autowired(required=true) 
	
	private BookService bookService;
	
	@RequestMapping(method=RequestMethod.GET,value="/books") 
	public List<Book> findAll(){    
		return bookService.allBooks();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/books")
	public Book createBook(@RequestBody Book book) { 
		return bookService.createBook(book);
		}
	
	@RequestMapping(method=RequestMethod.GET,value="/books/{id}") 
	public Book findBook(@PathVariable int id) { 
		return bookService.findBook(id);
		}
	
	@RequestMapping(method=RequestMethod.PUT,value="/books/{id}")  
	public Book updateBook(@PathVariable int id,@RequestBody Book book) {
		return bookService.update(id, book);
		}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/books/{id}")
	public Book delete(@PathVariable int id) {
		return bookService.delete(id);
		}	

}
