package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BookStoreProject.beans.Book;
import com.capgemini.BookStoreProject.beans.Review;
import com.capgemini.BookStoreProject.dao.BookDao;
import com.capgemini.BookStoreProject.dao.ReviewDao;
@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
BookDao bookDao;
@Autowired
ReviewDao reviewDao;
	@Override
	public Book findInformation(int bookId) {
		
	return 	bookDao.findById(bookId).get();
	
		
	}

	@Override
	public List<Review> booksReview() {
		return reviewDao.findAll();
		
	}

}
